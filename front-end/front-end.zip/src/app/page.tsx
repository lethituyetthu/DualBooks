
export default function Home() {
  return (
    
   <main>
    home
   </main>
  );
}
