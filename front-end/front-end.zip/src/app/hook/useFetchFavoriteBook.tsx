import React from 'react'

export default function useFetchFavoriteBook() {
  return (
    <div>useFetchFavoriteBook</div>
  )
}
