/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/@heroicons";
exports.ids = ["vendor-chunks/@heroicons"];
exports.modules = {

/***/ "(ssr)/./node_modules/@heroicons/react/outline/index.js":
/*!********************************************************!*\
  !*** ./node_modules/@heroicons/react/outline/index.js ***!
  \********************************************************/
/***/ ((module) => {

eval("let proxy = new Proxy(\n  {},\n  {\n    get: (obj, property) => {\n      if (property === '__esModule') {\n        return {}\n      }\n\n      throw new Error(\n        `You\\'re trying to import \\`@heroicons/react/outline/${property}\\` from Heroicons v1 but have installed Heroicons v2. Install \\`@heroicons/react@v1\\` to resolve this error.`\n      )\n    },\n  }\n)\n\nmodule.exports = proxy\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvQGhlcm9pY29ucy9yZWFjdC9vdXRsaW5lL2luZGV4LmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSwrREFBK0QsU0FBUztBQUN4RTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJvbnQtZW5kLy4vbm9kZV9tb2R1bGVzL0BoZXJvaWNvbnMvcmVhY3Qvb3V0bGluZS9pbmRleC5qcz9iYmY1Il0sInNvdXJjZXNDb250ZW50IjpbImxldCBwcm94eSA9IG5ldyBQcm94eShcbiAge30sXG4gIHtcbiAgICBnZXQ6IChvYmosIHByb3BlcnR5KSA9PiB7XG4gICAgICBpZiAocHJvcGVydHkgPT09ICdfX2VzTW9kdWxlJykge1xuICAgICAgICByZXR1cm4ge31cbiAgICAgIH1cblxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgWW91XFwncmUgdHJ5aW5nIHRvIGltcG9ydCBcXGBAaGVyb2ljb25zL3JlYWN0L291dGxpbmUvJHtwcm9wZXJ0eX1cXGAgZnJvbSBIZXJvaWNvbnMgdjEgYnV0IGhhdmUgaW5zdGFsbGVkIEhlcm9pY29ucyB2Mi4gSW5zdGFsbCBcXGBAaGVyb2ljb25zL3JlYWN0QHYxXFxgIHRvIHJlc29sdmUgdGhpcyBlcnJvci5gXG4gICAgICApXG4gICAgfSxcbiAgfVxuKVxuXG5tb2R1bGUuZXhwb3J0cyA9IHByb3h5XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/@heroicons/react/outline/index.js\n");

/***/ }),

/***/ "(ssr)/./node_modules/@heroicons/react/solid/index.js":
/*!******************************************************!*\
  !*** ./node_modules/@heroicons/react/solid/index.js ***!
  \******************************************************/
/***/ ((module) => {

eval("let proxy = new Proxy(\n  {},\n  {\n    get: (obj, property) => {\n      if (property === '__esModule') {\n        return {}\n      }\n\n      throw new Error(\n        `You\\'re trying to import \\`@heroicons/react/solid/${property}\\` from Heroicons v1 but have installed Heroicons v2. Install \\`@heroicons/react@v1\\` to resolve this error.`\n      )\n    },\n  }\n)\n\nmodule.exports = proxy\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvQGhlcm9pY29ucy9yZWFjdC9zb2xpZC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsNkRBQTZELFNBQVM7QUFDdEU7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQSIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250LWVuZC8uL25vZGVfbW9kdWxlcy9AaGVyb2ljb25zL3JlYWN0L3NvbGlkL2luZGV4LmpzP2RhMGYiXSwic291cmNlc0NvbnRlbnQiOlsibGV0IHByb3h5ID0gbmV3IFByb3h5KFxuICB7fSxcbiAge1xuICAgIGdldDogKG9iaiwgcHJvcGVydHkpID0+IHtcbiAgICAgIGlmIChwcm9wZXJ0eSA9PT0gJ19fZXNNb2R1bGUnKSB7XG4gICAgICAgIHJldHVybiB7fVxuICAgICAgfVxuXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBZb3VcXCdyZSB0cnlpbmcgdG8gaW1wb3J0IFxcYEBoZXJvaWNvbnMvcmVhY3Qvc29saWQvJHtwcm9wZXJ0eX1cXGAgZnJvbSBIZXJvaWNvbnMgdjEgYnV0IGhhdmUgaW5zdGFsbGVkIEhlcm9pY29ucyB2Mi4gSW5zdGFsbCBcXGBAaGVyb2ljb25zL3JlYWN0QHYxXFxgIHRvIHJlc29sdmUgdGhpcyBlcnJvci5gXG4gICAgICApXG4gICAgfSxcbiAgfVxuKVxuXG5tb2R1bGUuZXhwb3J0cyA9IHByb3h5XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/@heroicons/react/solid/index.js\n");

/***/ })

};
;