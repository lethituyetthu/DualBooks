/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
      domains: ['localhost'],  // Thêm 'localhost' vào danh sách các domain được phép
    },
  };
  
  export default nextConfig;
  